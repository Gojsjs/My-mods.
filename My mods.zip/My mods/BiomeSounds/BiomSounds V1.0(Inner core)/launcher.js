Launch({
	ChatColor: ModAPI.requireGlobal("ChatColor")
});